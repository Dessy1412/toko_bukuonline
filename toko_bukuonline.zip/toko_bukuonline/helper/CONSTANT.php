<?php

// connection
define("HOST", "localhost");
define("UNAME", "root");
define("PASS", "");
define("DB", "dbtoko_buku");

// tables
// define("TB_BARANG", "tb_barang");

?>